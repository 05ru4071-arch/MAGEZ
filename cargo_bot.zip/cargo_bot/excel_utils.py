import openpyxl
from openpyxl.styles import Alignment, Font, Border, Side
from openpyxl.drawing.image import Image as XLImage
from PIL import Image
import os
from config import LOGO_PATH, ORDERS_DIR
from datetime import datetime

def create_excel(user_id, products):
    wb = openpyxl.Workbook()
    ws = wb.active

    ws.merge_cells("B1:F1")
    ws["B1"] = "MAGEZ — торгово-логистическая компания"
    ws["B1"].font = Font(bold=True, color="FF0000", size=14)
    ws["B1"].alignment = Alignment(horizontal="center", vertical="center")

    if os.path.exists(LOGO_PATH):
        img = XLImage(LOGO_PATH)
        ws.add_image(img, "A1")

    headers = ["Фото", "Ссылка", "Цвет", "Размер", "Количество", "Комментарий"]
    ws.append(headers)

    thin_border = Border(left=Side(style='thin'), right=Side(style='thin'),
                         top=Side(style='thin'), bottom=Side(style='thin'))

    for p in products:
        pid, uid, photo, link, color, size, qty, comment = p
        row = [None, link, color, size, qty, comment]
        ws.append(row)
        row_num = ws.max_row
        for col in range(1, 7):
            cell = ws.cell(row=row_num, column=col)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = thin_border

        if photo and os.path.exists(photo):
            try:
                img = Image.open(photo).convert("RGB")
                png_path = photo + ".png"
                img.save(png_path, "PNG")
                img_excel = XLImage(png_path)
                ws.add_image(img_excel, f"A{row_num}")
            except Exception:
                pass

    for col in ws.columns:
        max_length = 20
        col_letter = openpyxl.utils.get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = max_length

    if not os.path.exists(f"{ORDERS_DIR}/{user_id}"):
        os.makedirs(f"{ORDERS_DIR}/{user_id}")

    filename = f"{ORDERS_DIR}/{user_id}/order_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    wb.save(filename)
    return filename
