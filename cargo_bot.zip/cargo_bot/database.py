import sqlite3
import os
from config import DB_PATH

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS invite_codes (
        code TEXT PRIMARY KEY,
        used INTEGER DEFAULT 0
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        photo_path TEXT,
        link TEXT,
        color TEXT,
        size TEXT,
        qty INTEGER,
        comment TEXT
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        file_path TEXT,
        created_at TEXT
    )""")

    conn.commit()
    conn.close()

def add_user(user_id, username):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)", (user_id, username))
    conn.commit()
    conn.close()

def check_code(code):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT used FROM invite_codes WHERE code = ?", (code,))
    row = c.fetchone()
    conn.close()
    if not row:
        return False
    return row[0] == 0

def use_code(code):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE invite_codes SET used = 1 WHERE code = ?", (code,))
    conn.commit()
    conn.close()

def add_code(code):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO invite_codes (code, used) VALUES (?, 0)", (code,))
    conn.commit()
    conn.close()

def get_clients():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT user_id, username FROM users")
    data = c.fetchall()
    conn.close()
    return data

def add_product(user_id, photo_path, link, color, size, qty, comment):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO products (user_id, photo_path, link, color, size, qty, comment) VALUES (?, ?, ?, ?, ?, ?, ?)",
              (user_id, photo_path, link, color, size, qty, comment))
    conn.commit()
    conn.close()

def get_products(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM products WHERE user_id = ?", (user_id,))
    rows = c.fetchall()
    conn.close()
    return rows

def update_product(product_id, field, value):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(f"UPDATE products SET {field} = ? WHERE id = ?", (value, product_id))
    conn.commit()
    conn.close()

def clear_products(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM products WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def add_order(user_id, file_path, created_at):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO orders (user_id, file_path, created_at) VALUES (?, ?, ?)", (user_id, file_path, created_at))
    conn.commit()
    conn.close()

def get_orders(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT file_path FROM orders WHERE user_id = ?", (user_id,))
    rows = c.fetchall()
    conn.close()
    return rows
